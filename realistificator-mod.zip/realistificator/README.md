# Realistificator 3000 (Fabric, Minecraft 26.3)

A gadget that turns blocks into pushable physics bodies. Bodies are real rigid bodies: they fall, rotate, tumble
over edges, slide with friction, collide with the world and each other, sink slowly in water, and can be built up
into bigger bodies (irregular shapes have an off-centre centre of mass, so they tip and roll realistically).

## Using it (hold the tool in your MAIN hand, a block in your OFF hand)

| Action | Result |
|---|---|
| Right-click a block, empty off-hand | Realistify that block into a physics body |
| Right-click a block or air, block in off-hand | Spawn a physics body from the off-hand block |
| Right-click a body, block in off-hand | Attach that block to the face you aimed at (bigger body) |
| Right-click a body, empty off-hand | Select it. Right-click a 2nd body to merge it into the 1st |
| Sneak + right-click a body | Dismantle it back into items |
| Walk into it / punch it | Push it. Hits and pushes away from the centre make it spin and tumble |

Craft: ender pearl on top, iron / slime / iron in the middle, redstone below.

## Build
JDK 25 + Gradle 9.3+ (9.5.1 recommended):

    gradle wrapper --gradle-version 9.5.1
    ./gradlew build

Jar ends up in `build/libs/`. Run in dev with `./gradlew runClient`.

## Known v1 limits
- Merging snaps the second body onto the first body's lattice (the second body's rotation is discarded).
- Blocks with facing (logs, stairs...) keep their own orientation rather than turning with a merged body.
- Players pass through bodies rather than standing on them (pushing works by walking into them).
- Blocks with inventories / block entities can't be Realistified.
- Attached blocks use the block's default state.
