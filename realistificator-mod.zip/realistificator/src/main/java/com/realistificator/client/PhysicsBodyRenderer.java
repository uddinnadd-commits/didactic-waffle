package com.realistificator.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.realistificator.entity.PhysicsBodyEntity;
import com.realistificator.entity.PhysicsCell;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.phys.Vec3;

/**
 * Draws each cell as a normal block model. The pose stack is already at the entity position, which is the
 * body's centre of mass, so we rotate there and then offset each cell relative to the centre of mass.
 */
public class PhysicsBodyRenderer extends EntityRenderer<PhysicsBodyEntity, PhysicsBodyRenderState> {
    public PhysicsBodyRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public PhysicsBodyRenderState createRenderState() {
        return new PhysicsBodyRenderState();
    }

    @Override
    public void extractRenderState(PhysicsBodyEntity entity, PhysicsBodyRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.cells = entity.getCells();
        state.rotation = entity.getRenderRotation(partialTick);
        Vec3 com = entity.getCom();
        state.comX = (float) com.x;
        state.comY = (float) com.y;
        state.comZ = (float) com.z;
    }

    @Override
    public void submit(PhysicsBodyRenderState state, PoseStack poseStack, SubmitNodeCollector collector, CameraRenderState camera) {
        poseStack.pushPose();
        poseStack.mulPose(state.rotation);
        for (PhysicsCell cell : state.cells) {
            poseStack.pushPose();
            // lattice centre is (x, y + 0.5, z); a block model's origin is its min corner (-0.5, -0.5, -0.5 from centre)
            poseStack.translate(cell.x() - state.comX - 0.5f, cell.y() - state.comY, cell.z() - state.comZ - 0.5f);
            collector.submitBlock(poseStack, cell.state(), state.lightCoords, OverlayTexture.NO_OVERLAY, state.outlineColor);
            poseStack.popPose();
        }
        poseStack.popPose();
        super.submit(state, poseStack, collector, camera);
    }
}
