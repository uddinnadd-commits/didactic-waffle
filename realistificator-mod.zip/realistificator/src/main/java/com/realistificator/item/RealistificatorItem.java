package com.realistificator.item;

import com.realistificator.ModEntities;
import com.realistificator.entity.PhysicsBodyEntity;
import com.realistificator.entity.PhysicsCell;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * The Realistificator 3000. Hold it in your MAIN hand; put a block in your OFF hand to feed it.
 *
 *  - Aim at a block, nothing in off-hand ........ Realistify that block (it becomes a physics body)
 *  - Aim at a block / air, block in off-hand .... Spawn a new physics body from the off-hand block
 *  - Aim at a body, block in off-hand ........... Attach that block to the face you aimed at
 *  - Aim at a body, empty off-hand .............. Select it; right-click a 2nd body to merge it into the 1st
 *  - Sneak + aim at a body ...................... Dismantle it back into items
 *  - Walk into / punch a body ................... Push it (off-centre pushes and punches make it tumble)
 */
public class RealistificatorItem extends Item {
    private static final double REACH = 6.0;
    private static final Map<UUID, UUID> SELECTED = new HashMap<>(); // player -> selected body

    public RealistificatorItem(Properties properties) {
        super(properties);
    }

    private record BodyHit(PhysicsBodyEntity body, PhysicsBodyEntity.Hit hit) {}

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(level instanceof ServerLevel sl)) {
            return InteractionResult.SUCCESS; // swing on the client; the server does the work
        }

        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getViewVector(1.0F).scale(REACH));

        BodyHit bodyHit = raycastBodies(sl, eye, end);
        HitResult picked = player.pick(REACH, 1.0F, false);
        BlockHitResult blockHit = picked.getType() == HitResult.Type.BLOCK ? (BlockHitResult) picked : null;

        double bodyDist = bodyHit == null ? Double.MAX_VALUE : eye.distanceToSqr(bodyHit.hit().point());
        double blockDist = blockHit == null ? Double.MAX_VALUE : eye.distanceToSqr(blockHit.getLocation());

        InteractionHand other = hand == InteractionHand.MAIN_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
        ItemStack offStack = player.getItemInHand(other);
        BlockState held = offStack.getItem() instanceof BlockItem bi ? bi.getBlock().defaultBlockState() : null;

        if (bodyHit != null && bodyDist <= blockDist) {
            return onBody(sl, player, bodyHit, held, offStack);
        }
        if (blockHit != null) {
            return onBlock(sl, player, blockHit, held, offStack);
        }
        return onAir(sl, player, eye, held, offStack);
    }

    // ------------------------------------------------------------ on a physics body

    private InteractionResult onBody(ServerLevel level, Player player, BodyHit bh, BlockState held, ItemStack offStack) {
        PhysicsBodyEntity body = bh.body();

        if (player.isShiftKeyDown()) {
            dismantle(level, body);
            SELECTED.remove(player.getUUID());
            return InteractionResult.SUCCESS;
        }

        if (held != null) {
            return attachBlock(level, player, bh, held, offStack);
        }

        // select / merge flow
        UUID selectedId = SELECTED.get(player.getUUID());
        Entity selected = selectedId == null ? null : level.getEntity(selectedId);
        if (selected instanceof PhysicsBodyEntity first && first != body && first.isAlive()) {
            if (merge(level, player, first, body)) {
                first.setGlowingTag(false);
                SELECTED.remove(player.getUUID());
            }
            return InteractionResult.SUCCESS;
        }
        if (selected == body) {
            body.setGlowingTag(false);
            SELECTED.remove(player.getUUID());
            msg(player, "Deselected.");
            return InteractionResult.SUCCESS;
        }
        if (selected != null) selected.setGlowingTag(false);
        body.setGlowingTag(true);
        SELECTED.put(player.getUUID(), body.getUUID());
        msg(player, "Selected. Right-click another body to merge it in, or right-click it again to cancel.");
        return InteractionResult.SUCCESS;
    }

    private InteractionResult attachBlock(ServerLevel level, Player player, BodyHit bh, BlockState held, ItemStack offStack) {
        PhysicsBodyEntity body = bh.body();
        if (body.getCells().size() >= PhysicsBodyEntity.MAX_CELLS) {
            msg(player, "That body is as big as it can get (" + PhysicsBodyEntity.MAX_CELLS + " blocks).");
            return InteractionResult.SUCCESS;
        }
        PhysicsCell src = body.getCells().get(bh.hit().cellIndex());
        // the face is in the body's own (lattice) frame, so this works no matter how the body is rotated
        int nx = src.x() + bh.hit().face().getStepX();
        int ny = src.y() + bh.hit().face().getStepY();
        int nz = src.z() + bh.hit().face().getStepZ();
        if (body.hasCell(nx, ny, nz)) {
            msg(player, "Something is already attached there.");
            return InteractionResult.SUCCESS;
        }
        if (body.cellBlocked(level, nx, ny, nz)) {
            msg(player, "No room to attach a block there.");
            return InteractionResult.SUCCESS;
        }
        body.addCells(List.of(new PhysicsCell(nx, ny, nz, held)));
        consume(player, offStack);
        feedback(level, body.cellCenterWorld(nx, ny, nz), 1.4f);
        return InteractionResult.SUCCESS;
    }

    /** Merges 'from' into 'into', snapping from's blocks onto into's lattice (rotation is snapped away). */
    private boolean merge(ServerLevel level, Player player, PhysicsBodyEntity into, PhysicsBodyEntity from) {
        if (into.getCells().size() + from.getCells().size() > PhysicsBodyEntity.MAX_CELLS) {
            msg(player, "Merged body would be too big (max " + PhysicsBodyEntity.MAX_CELLS + " blocks).");
            return false;
        }
        if (into.position().distanceTo(from.position()) > 8.0) {
            msg(player, "Those bodies are too far apart to merge.");
            return false;
        }

        Set<Long> taken = new HashSet<>();
        for (PhysicsCell c : into.getCells()) taken.add(key(c.x(), c.y(), c.z()));

        List<PhysicsCell> add = new ArrayList<>();
        for (PhysicsCell c : from.getCells()) {
            Vec3 centre = from.cellCenterWorld(c.x(), c.y(), c.z());
            Vector3d l = into.worldToLattice(centre);
            int nx = (int) Math.round(l.x), ny = (int) Math.round(l.y - 0.5), nz = (int) Math.round(l.z);
            if (!taken.add(key(nx, ny, nz))) {
                msg(player, "Those bodies overlap too much to merge. Pull them apart a bit and try again.");
                return false;
            }
            if (into.cellBlocked(level, nx, ny, nz)) {
                msg(player, "No room to merge them here.");
                return false;
            }
            add.add(new PhysicsCell(nx, ny, nz, c.state()));
        }
        into.addCells(add);
        from.discard();
        feedback(level, into.getBoundingBox().getCenter(), 1.0f);
        msg(player, "Merged!");
        return true;
    }

    private static long key(int x, int y, int z) {
        return ((long) (x & 0x1FFFFF) << 42) | ((long) (y & 0x1FFFFF) << 21) | (long) (z & 0x1FFFFF);
    }

    private void dismantle(ServerLevel level, PhysicsBodyEntity body) {
        for (PhysicsCell c : body.getCells()) {
            ItemStack stack = new ItemStack(c.state().getBlock().asItem());
            if (stack.isEmpty()) continue;
            Vec3 p = body.cellCenterWorld(c.x(), c.y(), c.z());
            Block.popResource(level, BlockPos.containing(p), stack);
        }
        feedback(level, body.getBoundingBox().getCenter(), 0.8f);
        body.discard();
    }

    // ------------------------------------------------------------ on a world block

    private InteractionResult onBlock(ServerLevel level, Player player, BlockHitResult hit, BlockState held, ItemStack offStack) {
        BlockPos pos = hit.getBlockPos();

        if (held != null) {
            BlockPos target = pos.relative(hit.getDirection());
            if (!spawnBody(level, target.getX() + 0.5, target.getY(), target.getZ() + 0.5, held)) {
                msg(player, "No room for a physics block there.");
                return InteractionResult.SUCCESS;
            }
            consume(player, offStack);
            return InteractionResult.SUCCESS;
        }

        BlockState state = level.getBlockState(pos);
        if (state.isAir()) return InteractionResult.PASS;
        if (state.getDestroySpeed(level, pos) < 0) {
            msg(player, "That block is too stubborn to Realistify.");
            return InteractionResult.SUCCESS;
        }
        if (level.getBlockEntity(pos) != null) {
            msg(player, "Blocks with inventories or data can't be Realistified (yet).");
            return InteractionResult.SUCCESS;
        }
        level.removeBlock(pos, false);
        if (!spawnBody(level, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, state)) {
            level.setBlock(pos, state, Block.UPDATE_ALL); // put it back
            msg(player, "Couldn't Realistify that block.");
        }
        return InteractionResult.SUCCESS;
    }

    // ------------------------------------------------------------ in the air

    private InteractionResult onAir(ServerLevel level, Player player, Vec3 eye, BlockState held, ItemStack offStack) {
        if (held == null) {
            UUID selectedId = SELECTED.remove(player.getUUID());
            Entity selected = selectedId == null ? null : level.getEntity(selectedId);
            if (selected != null) {
                selected.setGlowingTag(false);
                msg(player, "Selection cleared.");
            } else {
                msg(player, "Aim at a block, or hold a block in your off-hand to Realistify it.");
            }
            return InteractionResult.SUCCESS;
        }
        Vec3 p = eye.add(player.getViewVector(1.0F).scale(2.5));
        if (!spawnBody(level, p.x, p.y - 0.5, p.z, held)) {
            msg(player, "No room for a physics block there.");
            return InteractionResult.SUCCESS;
        }
        consume(player, offStack);
        return InteractionResult.SUCCESS;
    }

    // ------------------------------------------------------------ helpers

    /** (x, yBottom, z) is the bottom-centre of the new block. The body's origin is its centre of mass. */
    private static boolean spawnBody(ServerLevel level, double x, double yBottom, double z, BlockState state) {
        AABB footprint = new AABB(x - 0.5, yBottom, z - 0.5, x + 0.5, yBottom + 1.0, z + 0.5);
        if (level.getBlockCollisions(null, footprint.deflate(1.0E-3)).iterator().hasNext()) return false;

        PhysicsBodyEntity body = new PhysicsBodyEntity(ModEntities.PHYSICS_BODY, level);
        body.setPos(x, yBottom + 0.5, z);
        body.setCells(List.of(new PhysicsCell(0, 0, 0, state)));
        level.addFreshEntity(body);
        feedback(level, new Vec3(x, yBottom + 0.5, z), 1.2f);
        return true;
    }

    private static BodyHit raycastBodies(ServerLevel level, Vec3 from, Vec3 to) {
        BodyHit best = null;
        double bestDist = Double.MAX_VALUE;
        AABB area = new AABB(from, to).inflate(2.0);
        for (PhysicsBodyEntity body : level.getEntitiesOfClass(PhysicsBodyEntity.class, area)) {
            Optional<PhysicsBodyEntity.Hit> hit = body.rayCast(from, to);
            if (hit.isEmpty()) continue;
            double d = from.distanceToSqr(hit.get().point());
            if (d < bestDist) {
                bestDist = d;
                best = new BodyHit(body, hit.get());
            }
        }
        return best;
    }

    private static void consume(Player player, ItemStack stack) {
        if (!player.hasInfiniteMaterials()) stack.shrink(1);
    }

    private static void msg(Player player, String text) {
        player.displayClientMessage(Component.literal(text), true);
    }

    private static void feedback(ServerLevel level, Vec3 at, float pitch) {
        level.playSound(null, at.x, at.y, at.z, SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.BLOCKS, 1.0f, pitch);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y, at.z, 14, 0.3, 0.3, 0.3, 0.02);
    }
}
